
// Define
#ifndef __FRIENDHEAD__
#define __FRIENDHEAD__

// Find out answer
int findSample(int n,int confidence[],int host[],int protocol[]);

#endif
